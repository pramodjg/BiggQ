package com.wemob.app.biggq.data;

/**
 * Created by admin on 8/31/2017.
 */

public class NotificationData {

    private String username;
    private String activity;
    private String entity;
    private String timeofnotification;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getActivity() {
        return activity;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public String getEntity() {
        return entity;
    }

    public void setEntity(String entity) {
        this.entity = entity;
    }

    public String getTimeofnotification() {
        return timeofnotification;
    }

    public void setTimeofnotification(String timeofnotification) {
        this.timeofnotification = timeofnotification;
    }
}
