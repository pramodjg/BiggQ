package com.wemob.app.biggq.widget;

import android.content.Context;
import android.util.AttributeSet;

import com.twitter.sdk.android.core.identity.TwitterLoginButton;

/**
 * Created by admin on 9/13/2017.
 */

public class CustomTwitterButton extends TwitterLoginButton {
    public CustomTwitterButton(Context context) {
        super(context);
    }

    public CustomTwitterButton(Context context, AttributeSet attrs) {
        super(context, attrs);

    }

    public CustomTwitterButton(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);

    }

}
