package com.wemob.app.biggq;

public class Config {

    public static final boolean SHOW_LOGS = true;

    public static final boolean SHOW_DEBUG_RECT = true;
}
