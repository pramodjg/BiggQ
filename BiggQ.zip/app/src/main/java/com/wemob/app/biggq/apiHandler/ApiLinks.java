package com.wemob.app.biggq.apiHandler;

/**
 * Created by admin on 9/14/2017.
 */

public class ApiLinks {
    public static String baseURL="http://monkhub.com/bigqlaunch/";
    public static String loginURL="http://monkhub.com/bigqlaunch/json/login_email.php";
    public static String feedURL=baseURL+"json/load_feeds_type.php";
    public static String searchCelebrity=baseURL+"json/search_celebrity.php";
    public static String feedDetails=baseURL+"json/question_id.php";
    public static String videobasepath=baseURL+"video_uploader/upload/";
}
