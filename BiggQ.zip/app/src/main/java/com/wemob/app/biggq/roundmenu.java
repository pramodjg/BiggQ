package com.wemob.app.biggq;

import android.content.Context;
import android.support.v4.view.ViewGroupCompat;
import android.util.AttributeSet;
import android.view.ViewGroup;

/**
 * Created by admin on 8/20/2017.
 */

public class roundmenu extends ViewGroup {


    public roundmenu(Context context) {
        super(context);
    }

    public roundmenu(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public roundmenu(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }


    @Override
    protected void onLayout(boolean b, int i, int i1, int i2, int i3) {


    }
}
